# Projeto Caos — Android (projeto-fonte)

Este é o projeto-fonte Android inicial do protótipo Projeto Caos 0.2.
Ele incorpora o jogo HTML como recurso local em um WebView, portanto o jogo
não precisa abrir um arquivo HTML separado nem de conexão com a internet.

## Como gerar o APK

1. Instale o Android Studio (versão compatível com Android Gradle Plugin 8.7.3).
2. Abra esta pasta (`ProjetoCaosAndroid`) no Android Studio.
3. Aguarde a sincronização do Gradle e a instalação do Android SDK 35, se solicitada.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

Para instalar no aparelho, transfira o APK e permita a instalação dessa origem
quando o Android solicitar.

## Estado e limitações

- `versionName`: 0.2.0
- `applicationId`: com.projetocaos.game
- Min SDK: 23 (Android 6.0)
- O protótipo atual é incorporado localmente.
- Ainda não há assinatura de distribuição/Play Store.
- O combate, balanceamento, cenas e progressão continuam em desenvolvimento.

Este ambiente de criação não possui Android SDK nem Gradle instalado; portanto
o APK não foi compilado aqui. O pacote contém o projeto-fonte pronto para abrir
e compilar no Android Studio.

## Compilação em nuvem (sem instalar Android Studio no celular)

O projeto inclui `.github/workflows/build-apk.yml`. Se você enviar o conteúdo
desta pasta para um repositório GitHub, abra **Actions**, selecione
**Build Projeto Caos APK** e toque em **Run workflow**. Ao terminar, baixe
o artefato `projeto-caos-debug-apk` na execução. O APK gerado é de depuração,
não um pacote assinado para publicação na Play Store.
